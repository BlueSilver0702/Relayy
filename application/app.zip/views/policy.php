<div class="section_wrapper container">
    <div class="post-text">
		<h4>Information we collect:</h4>
		<p>Relayy provides you with many different ways to use our services when you create a Relayy Account. 
    		Our Privacy Policy describes Relayy's policies on how we collect, use and disclose user information. When you create an account,</p>
    	<p>Relayy provides you with many different ways to use our services when you create a Relayy Account. 
    		Our Privacy Policy describes Relayy's policies on how we collect, use and disclose user information. When you create an account,</p>
		<h4>Relayy Messaging, Groups, Following, Lists and other Public Information: </h4>
		<p>Relayy provides you with many different ways to use our services when you create a Relayy Account. 
    		Our Privacy Policy describes Relayy's policies on how we collect, use and disclose user information. When you create an account,</p>
		<h4>Our Policy towards Children</h4>		
		<p>Relayy provides you with many different ways to use our services when you create a Relayy Account. 
    		Our Privacy Policy describes Relayy's policies on how we collect, use and disclose user information. When you create an account,</p>
		<h4>Changes to this Policy</h4>
		<p>Relayy provides you with many different ways to use our services when you create a Relayy Account. 
    		Our Privacy Policy describes Relayy's policies on how we collect, use and disclose user information. When you create an account,</p>
    </div>
</div>