<div class="pull-left" id="l-side">
  <div class="col-md-12">
    <div class="list-header">
      <h4 class="list-header-title">History</h4>
    </div>
    <div class="list-group pre-scrollable nice-scroll" id="dialogs-list" tabindex="0" style="overflow: hidden; outline: none;">
    	<a href="#" class="list-group-item active" id="56e10fd5a0eb47a41d000056" onclick="triggerDialog('56e10fd5a0eb47a41d000056')">
    		<span class="badge" style="display: none;">0</span>
    		<h4 class="list-group-item-heading">
    			<img src="assets/images/ava-group.svg" width="30" height="30" class="round">&nbsp;&nbsp;&nbsp;
    			<span>bluesilver0702@gmail.com, Sean D, Sean A</span>
    		</h4>
    		<p class="list-group-item-text last-message"></p>
    	</a>
    	<a href="#" class="list-group-item inactive" id="56e10f74a28f9abe2000002c" onclick="triggerDialog('56e10f74a28f9abe2000002c')">
    		<span class="badge" style="display: none;">0</span>
    		<h4 class="list-group-item-heading">
    			<img src="assets/images/ava-group.svg" width="30" height="30" class="round">&nbsp;&nbsp;&nbsp;
    			<span>bluesilver0702@gmail.com, Blue Silver, Sean D, Sean A, Dennis Chow</span>
    		</h4>
    		<p class="list-group-item-text last-message"></p>
    	</a>
    	<a href="#" class="list-group-item inactive" id="56d993b3a28f9a9d7a000081" onclick="triggerDialog('56d993b3a28f9a9d7a000081')">
    		<span class="badge" style="display: none;">0</span>
    		<h4 class="list-group-item-heading">
    			<img src="assets/images/ava-group.svg" width="30" height="30" class="round">&nbsp;&nbsp;&nbsp;
    			<span>bluesilver0702@gmail.com, sean@rxaprojects.com</span>
    		</h4>
    		<p class="list-group-item-text last-message">Hi</p>
    	</a>
    	<a href="#" class="list-group-item inactive" id="56d9a9fea0eb474665000005" onclick="triggerDialog('56d9a9fea0eb474665000005')">
    		<span class="badge" style="display: none;">0</span>
    		<h4 class="list-group-item-heading">
    			<img src="assets/images/ava-group.svg" width="30" height="30" class="round">&nbsp;&nbsp;&nbsp;
    			<span>bluesilver0702@gmail.com, Dennis_260773197588000</span>
    		</h4>
    		<p class="list-group-item-text last-message">Hi</p>
    	</a>
    	<a href="#" class="list-group-item inactive" id="56d992daa28f9a42c7000013" onclick="triggerDialog('56d992daa28f9a42c7000013')">
    		<span class="badge" style="display: none;">0</span>
    		<h4 class="list-group-item-heading">
    			<img src="assets/images/ava-group.svg" width="30" height="30" class="round">&nbsp;&nbsp;&nbsp;
    			<span>bluesilver0702@gmail.com, sean@rxaprojects.com, sean1@rxaprojects.com</span>
    		</h4>
    		<p class="list-group-item-text last-message">sfsdf</p>
    	</a>
    	<a href="#" class="list-group-item inactive" id="56d99460a0eb476e0e00004e" onclick="triggerDialog('56d99460a0eb476e0e00004e')">
    		<span class="badge" style="display: none;">0</span>
    		<h4 class="list-group-item-heading">
    			<img src="assets/images/ava-group.svg" width="30" height="30" class="round">&nbsp;&nbsp;&nbsp;
    			<span>bluesilver0702@gmail.com, sean1@rxaprojects.com, Dennis_260773197588000</span>
    		</h4>
    		<p class="list-group-item-text last-message">Hello</p>
    	</a>
    	<a href="#" class="list-group-item inactive" id="56d98ee6a0eb473702000033" onclick="triggerDialog('56d98ee6a0eb473702000033')">
    		<span class="badge" style="display: none;">0</span>
    		<h4 class="list-group-item-heading">
    			<img src="assets/images/ava-group.svg" width="30" height="30" class="round">&nbsp;&nbsp;&nbsp;
    			<span>bluesilver0702@gmail.com, sean@rxaprojects.com, sean1@rxaprojects.com</span>
    		</h4>
    		<p class="list-group-item-text last-message">[attachment]</p>
    	</a>
    </div>
  </div>
</div>